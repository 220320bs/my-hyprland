#!/bin/bash

# Get the current date and time
datetime=$(date "+%Y-%m-%d %H:%M")

# Create the screenshot directory if it doesn't exist
mkdir -p ~/Picturces/screenhosts

# Capture the screenshot and save it to the specified directory
grim ~/Picturces/screenhosts"$datetime.png"
