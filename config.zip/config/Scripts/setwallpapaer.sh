#!/bin/bash

DIR="/home/zlc/Pictures/wallpaper"

# Edit below to control the images transition
export SWWW_TRANSITION_FPS=60
export SWWW_TRANSITION_STEP=2

# Find a random image file in the directory
img=$(find "$DIR" -type f | shuf -n 1)

# Set the image as the wallpaper
swww img "$img"

