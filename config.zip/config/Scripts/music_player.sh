#!/bin/bash

# 你可以根据自己的终端程序修改以下变量
TERMINAL="kitty"  # 使用你喜欢的终端程序，比如gnome-terminal, konsole, xterm等

# 检查是否已经安装了musicfox，如果没有则给出提示
if ! command -v musicfox &>/dev/null; then
  echo "Error: musicfox is not installed. Please install it first."
  exit 1
fi

# 启动终端，并运行musicfox
$TERMINAL -e musicfox

# 你也可以使用其他终端启动musicfox，比如xterm:
# xterm -e musicfox
