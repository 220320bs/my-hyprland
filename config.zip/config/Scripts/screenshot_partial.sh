
#!/bin/bash

# Get the current date and time
datetime=$(date "+%Y-%m-%d %H:%M")

# Capture a part of the screen and save it to the specified directory
3
